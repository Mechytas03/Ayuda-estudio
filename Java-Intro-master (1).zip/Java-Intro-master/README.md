# Java-Intro

# ALGUNOS ATAJOS en JAVA con Netbeans

Ctrl. + E : Borra línea de codigo donde estoy posicionado.<br />
Ctrl. + S : Guarda los cambios en la clase que estoy posicionado.<br />
Shift. + F6 : RUN main proyect (actual).<br />
Alt. + Shift + F : Le da formato al código.(queda mas legible, ordenado)<br />
Alt + Enter : Se usa sobre el texto subrayado para ver la sugerencia que nos hace el IDE cuando hay<br />
algún error de sintaxis o se necesita realizar algún import o surround.<br />
Ctrl. + Shift + : Hace una copia de la línea de código que estabas posicionado.<br />
Shift + DELETE : Borra toda la línea de código donde estoy posicionada.<br />
Ctrl. + Space : Completa el código que estamos escribiendo.<br />
Ctrl. + U U : Convierte el código a mayúsculas.<br />
Ctrl. + U L : Convierte el código a minúsculas.<br />
Alt + Insert : Agrega constructores, métodos accesotes, propiedades.(codigos predeterminados)<br />
Ctrl. + G : Ir numero de línea concreto(introducida x ventana auxiliar).<br />
Ctrl. +[NOMBRECLASE] : Me despliega todas las características de la clase<br />

# Para completar formatos
if. + TAB : Genera los bloques if.<br />
sout. + TAB : Genera los System.out.println<br />
fori + TAB : Genera el codigo necesario para hacer un for.<br />
sw + TAB : Genera el switch.<br />
whilexp/whilen/whileit + TAB : Genera los bloques while.<br />
dowhile + TAB : Genera los bloques dowhile.<br />
PSVM + TAB : Genera la función main.<br />

# Para crear propios ATAJOS
Tools / Options / Editor / CodeTemplates / New :<br />
-Primero voy a poner la abreviatura para llamar a mi “código”<br />
-Luego escribo el código a utilizar<br />
