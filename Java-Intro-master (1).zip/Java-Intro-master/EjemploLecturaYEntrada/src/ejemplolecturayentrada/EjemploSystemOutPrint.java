package ejemplolecturayentrada;


public class EjemploSystemOutPrint {

    public static void main(String[] args) {
        
        System.out.println("Hola mundo"); // Escribir normal
        
        System.out.print("Hola"); // Escribir Sin Saltar
        
        System.out.print("Mundo"); // Escribir Sin Saltar
        
        int numero = 20;
        
        System.out.println("El valor del numero es: " + numero); // Mostramos el valor de numero
       
        
        
        
    }

}
